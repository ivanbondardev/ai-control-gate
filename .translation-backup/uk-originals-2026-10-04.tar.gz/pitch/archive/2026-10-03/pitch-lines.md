# Пітч: рядки для використання

Оновлено: 2026-10-03. Усі тексти для виголошення — англійською; українською — лише для внутрішнього розуміння.

> **Історичний документ (позначено 2026-10-03, 16:00).** Тексти припускають працююче демо, яке **видалено** 3 жовтня 2026. Формулювання «I already have the action half running» і «половина вже працює» неправдиві для поточного стану. Перед використанням у поданні тексти треба переписати. Код лишається в історії git (коміт `52f1d87`).

**Що змінилося проти 2 жовтня.** Критерії відомі: Robustness+Guardrails 30%, Architecture 20%, Security Reporting 20%, Self-Testing 20/15%, Practical 10/15%. **Новизна ідеї та дизайн екрана не оцінюються взагалі** — тож пітч будується не на «яка гарна ідея», а на «ось що працює і ось чим доведено». Завдання вимагає **гібридного** захисту, тому формулювання «модель не потрібна» замінено на «модель — детектор, політика — арбітр».

## Головне речення (одне на весь проєкт)

> **Everything passes through one layer: content is redacted before it leaves, actions are decided before they run.** Deterministic policy makes the call; the model supplies a signal, never a verdict — and every step leaves tamper-evident evidence. Control is what makes wider autonomy safe, not what slows it down.

Українською: усе проходить через один шар — вміст приховується до виходу назовні, дії вирішуються до виконання. Рішення ухвалює детермінована політика; модель дає сигнал, а не вердикт. Контроль — це те, що дозволяє дати агентам більше прав, а не те, що їх забирає.

## Ключове розрізнення, яке треба вміти сказати вголос

> *We do use a model — as a detector, not as a judge. It tells us "this looks like social engineering, confidence 0.8". It never tells us "allow this". The threshold lives in the policy file, which is why we can test it and replay it.*

Це відповідь на два різні питання журі: «чому рішення не в моделі» **і** «де тут семантичний контроль, який вимагає завдання». Обидві відповіді — одним реченням.

## 30 секунд — для набору команди (історично: з прототипом на екрані; прототипу немає з 3 жовтня 2026)

> «Everything an agent reads and everything it does goes through one layer. Content gets redacted before it reaches an external model. Actions get decided before they execute — allow, block, or escalate. I already have the action half running: allowed, blocked, and approved-after-escalation, with a hash-chained audit trail. I'm adding the content half now. I need someone who knows what an auditor would accept, and someone who can make the screen obvious in three seconds.»

Українською: половина вже працює; шукаю людину з ризику/комплаєнсу і фронтендера.

## 30 секунд — три варіанти вступу для журі

**Якщо замовник — платформа AI / продуктивність розробників:**
> «Your developers already run agents against real repositories and systems. Today the only two options are full access or no access. We built the missing third option: a layer agents cannot go around — policy-enforced execution at the tool boundary, with zero added steps for the routine 80%, and content redaction before anything leaves your perimeter.»

**Якщо замовник — cyber / identity:**
> «An agent is not a user and not a service account. It reads untrusted content, it can be manipulated, and it acts. We give it an owner, a scoped credential with an expiry, a policy decision point in front of every action — and we redact sensitive content before it reaches any external model. The raw data never leaves.»

**Якщо замовник — ризик / комплаєнс / AI governance:**
> «Every interaction produces something you can defend: which control fired, which rule applied, who approved, what actually happened — in a tamper-evident record you can hand to an auditor. And when the model is unavailable, the layer says so instead of pretending. Control here is evidence, not vibes.»

## 60 секунд — повний пітч

1. **Проблема (їхніми словами).** Агенти читають недовірений вміст і діють: торкаються ресурсів і виконують складні процеси. Ризики: розкриття даних, несанкціоновані дії, непередбачувані витрати. Традиційні інструменти безпеки цього не покривають.
2. **Розрив.** Наявні варіанти — або журнал, який лише описує, або повна заборона, яка зупиняє роботу. А вимога завдання — **гібрид**: детерміновані контролі **і** семантичні.
3. **Наше рішення — два рубежі.** Вміст: детермінований скан на PII й секрети, редірект **до** виходу назовні, семантичний сигнал. Дія: точка ухвалення рішень у шляху виконання. Модель дає сигнал — політика вирішує. Людина бачить лише винятки.
4. **Демо.** Шість сцен: дозволено · заблоковано · ескальовано й погоджено · атака не проходить · **редірект PII перед виходом** · **семантичний сигнал → рішення політики**.
5. **Доказ.** N спроб атаки → 0 виконань; M редіректів; p95 рішення окремо від латентності провайдера; витрачені токени; частка дій без жодного додаткового кроку людини.
6. **Межі.** Мок-інструменти, спрощені політики, немає реальних IAM; семантичний контроль — не продакшн-класифікатор. Чесний список підвищує довіру.
7. **Прохання.** «Чи є сенс показати це комусь у вас, і з ким нам поговорити наступного тижня?»

## Цитати-опори — відповіді журі

Правило: кожен рядок нижче — **факт джерела**: так почуто в автопідписі виступу на конференції AI Engineer. Цитата підтверджує, що напрям уже названо в спільноті, а не те, що ми праві. Перед публічним уживанням звірити з первинним записом (посилання в кінці). Імена й організації взяті з назв виступів або зі слів самих доповідачів; де ім'я в записі не звучить — це атрибуція з назви, а не зі сцени. **Жодна з цитат не стосується версії специфікації MCP** — у 35 виступах теки версію не названо жодного разу, тож тверджень про відповідність специфікації на них не будувати.

**1. «Контрольної площини протокол не дає» — на питання «чи не робить це сам MCP?»**

> "The protocol itself doesn't enforce like specific observability." — Mahesh Murag, Anthropic
> "The client is responsible for dealing with that information." — David Soria Parra, Anthropic

Що сказати: *MCP guarantees the wire, not the control plane — and the client is explicitly responsible for what happens next. That is the layer we built.*

**2. «Шлюз перед викликами інструментів — уже названий патерн»**

> "a tool in between … filters which servers it has access to" — Mahesh Murag, Anthropic
> "enforcing policy", "ban malicious servers" — John Welsh, Anthropic (розповідає про MCP gateway)

Що сказати: *We are not inventing a category. We are adding the mechanics: ordered rules, default deny, escalation, receipts.*

**3. «Помилка — це промпт» — на питання, чому gate переписує відповідь інструмента**

> "errors are prompts" — Jeremiah Lowin, Prefect / FastMCP
> "Examples are contracts" — там само

Що сказати: *The gate hands the model a normalized error and keeps the raw server text in the audit trail.*

**4. «Керує хост» — на питання «а якщо це MCP-клієнт?»**

> "the host decides what to do" — Ido Salomon & Liad Yosef, MCP Apps
> "the control is in the hands of the host" — ті самі доповідачі, другий запис того самого виступу

Що сказати: *In our layer the decision is not in the host and not in the model: it is in a file a human signed.*

**5. «Реєстр — це не довіра»**

> "simply having a registry doesn't solve the problem" — Henry Mao, Smithery

Що сказати: *A server catalog is not trust. The gate evaluates the action, not the vendor.*

**6. «Default deny — не екзотика»**

> "you start with something that has no capabilities" — Sunil Pai, Cloudflare
> "They're blocked by default" — RL Nabors, WebMCP

Що сказати: *Default deny is the same construction principle, applied to business actions.*

**Джерела (автопідписи конференції AI Engineer; звірити перед публічним уживанням):**

| Скорочено | Виступ | URL |
|---|---|---|
| Murag, Anthropic | Building Agents with Model Context Protocol | <https://www.youtube.com/watch?v=kQmXtrmQ5Zg> |
| Soria Parra, Anthropic | The Future of MCP | <https://www.youtube.com/watch?v=v3Fr2JR47KA> |
| Welsh, Anthropic | Remote MCPs: What we learned from shipping | <https://www.youtube.com/watch?v=0NHCyq8bBcM> |
| Lowin, Prefect | Your MCP Server is Bad (and you should feel bad) | <https://www.youtube.com/watch?v=96G7FLab8xc> |
| Salomon & Yosef | MCP Apps: Extending the Frontier | <https://www.youtube.com/watch?v=-jY2T2PiJBE> |
| Pai, Cloudflare | Code Mode: Let the Code do the Talking | <https://www.youtube.com/watch?v=8txf05vVVl4> |
| Nabors, WebMCP | Introducing WebMCP: Agents in the Browser | <https://www.youtube.com/watch?v=LMbeDEQO6QM> |
| Mao, Smithery | Are MCPs Overhyped? A Rant about MCPs | <https://www.youtube.com/watch?v=tOou_GJ9Ddk> |

Повний розбір — у ../talks/mcp-and-ai-agents/synthesis.md (archive reference: `../talks/mcp-and-ai-agents/synthesis.md`); конспекти кожного виступу — у `talks/mcp-and-ai-agents/notes/`.

## Фрази, яких не вживати

- «AI safety platform» — надто широко, читається як «нічого конкретного».
- **«Ми використовуємо AI, щоб перевіряти AI»** — так казати не можна, але й заперечувати модель теж уже не можна: завдання **вимагає** семантичних контролів. Правильне формулювання — з розділу «Ключове розрізнення» вище: модель детектує, політика вирішує. Різниця між «модель радить людині» і «модель дає сигнал, а поріг лежить у файлі» — це різниця між лотереєю й контрольованою системою.
- **«Ми обходимося без моделі»** — пряме протиріччя з вимогою CRIETRIA:29. Не казати.
- «Ми блокуємо все небезпечне» — суперечить другій половині питання Goldman.
- «Це можна масштабувати на весь банк» — передчасно; краще показати один завершений сценарій.
- «Дані не виходять назовні» без уточнення. Точне формулювання: **сирі дані не виходять назовні — назовні йде вже прихований вміст.** Різниця принципова, і її треба сказати вголос, а не дати журі здогадатися.
