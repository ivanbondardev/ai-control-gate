# Bash-сценарії для Action Gate

**Факт реалізації набору:** 53 описи сценаріїв у `cases.json`, 39 JSON-шаблонів OpenAI Responses, Bash-транспорт через `curl`, окремі скрипти агентського циклу, retry, конкурентного бюджету та експорту звітності. Це клієнтський тестовий набір; він не реалізує модельний proxy.

**Факт рішення власника:** формат і реальний провайдер — OpenAI за замовчуванням; емулятор LLM не створюємо. [Доручення](../../sources/openai-request-format-decision-2026-10-04.md). Ключ провайдера налаштовується **на Gate**, клієнтські скрипти його не читають і не пересилають. `GATE_TOKEN` — окрема ідентичність клієнта; за замовчуванням використовується синтетичний токен з локального реєстру.

**Факт реалізації:** `/v1/responses` підтримує обмежений OpenAI Responses-профіль, function calling і буферизований SSE. [Контракт](../../app/contracts/model-proxy.md), [живі докази та межі](../../sources/model-proxy-implementation-2026-10-04.md). Повний набір 53 сценаріїв під усіма policy profiles ще не підтверджений.

Статуси кожного ID, історичні результати та межі перевірки копії зведено в [матриці](../../docs/23-bash-scenario-matrix.md). Поточний документ описує запуск і assertions.

## Запуск із локального термінала

**Факт реалізації:** скрипти виконуються на твоєму комп’ютері, поза контейнерами. Типова адреса — `http://localhost` (порт 80); також підтримується `http://127.0.0.1`. Traefik маршрутизує обидві адреси до Gate. Запити на loopback оминають системний HTTP proxy. Docker потрібен для серверного стека, але клієнтські скрипти не викликають Docker і не потребують `docker exec`.

```bash
# Run from the repository root
./scripts/gate-scenarios/preflight.sh
./scripts/gate-scenarios/run.sh --case M02

# Якщо серверний порт змінений на 8080:
GATE_BASE_URL=http://localhost:8080 ./scripts/gate-scenarios/preflight.sh

# Можна запускати з будь-якого робочого каталогу:
./scripts/gate-scenarios/run.sh --list
```

**Передумова:** серверний стек уже запущений, а порт відповідає `TRAEFIK_HTTP_PORT` у серверній конфігурації. `GATE_BASE_URL` змінює лише адресу клієнта, не серверний порт. Для MCP потрібні запущені MCP-сервіси та опублікований каталог. Модельний маршрут `/v1/responses` реалізований; ключ OpenAI та дозволена модель налаштовуються на сервері.

## Команди сценаріїв

Потрібні Bash 3.2+, curl з підтримкою `--header @file` і Python 3.9+. `jq`, OpenAI SDK і встановлення пакетів не потрібні.

```bash
./scripts/gate-scenarios/run.sh --list
./scripts/gate-scenarios/run.sh --check
./scripts/gate-scenarios/preflight.sh

# Підставити модель, дозволену політикою Gate та доступну провайдерському акаунту.
export OPENAI_MODEL=gpt-5-nano-2025-08-07
./scripts/gate-scenarios/run.sh --case L01
./scripts/gate-scenarios/run.sh --profile baseline

# MCP має бути опублікований і мати відповідну політику.
./scripts/gate-scenarios/run.sh --case M02
OPENAI_REASONING_EFFORT=minimal ./scripts/gate-scenarios/agent-loop.sh KB-1042
./scripts/gate-scenarios/retry.sh
./scripts/gate-scenarios/report.sh

# Довільний запит судді; у JSON вказати справжній model ID.
./scripts/gate-scenarios/ad-hoc.sh /path/to/request.json
```

**Факт поведінки скриптів:** `--check` і тести валідатора не викликають мережу. `preflight.sh` лише читає readiness та ідентичність; він не перевіряє ключ OpenAI. Запуск модельного сценарію може витрачати кошти реального провайдера. Скрипти не роблять автоматичних retry, redirect або нескінченних циклів. Модель не вибирається мовчки за профілем семантичного детектора.

| Змінна | Призначення |
|---|---|
| `GATE_BASE_URL` | Типово `http://localhost`; корінь Gate без `/v1` |
| `OPENAI_MODEL` | Реальна дозволена модель для генерації; обов'язкова для модельних сценаріїв, крім malformed JSON |
| `GATE_PRINCIPAL` | Типово `support-agent` |
| `GATE_TOKEN` | Токен цього principal; за відсутності — локальний синтетичний реєстр |
| `RESULT_DIR` | Нова, порожня тека доказів; типово у gitignored `evidence/gate-scenarios/…` |
| `REQUEST_TIMEOUT_SECONDS` | Клієнтський timeout, типово 60 с; це не доказ серверного time budget |
| `REPORT_PRINCIPAL` | Типово `operator-local`; для own-scope можна `support-agent` |
| `REPORT_SINCE`, `REPORT_UNTIL` | ISO-8601 з часовою зоною; типово попередні 15 хвилин |

Коли потрібен нестандартний токен звітного principal, задайте одночасно `GATE_PRINCIPAL=operator-local GATE_TOKEN=… REPORT_PRINCIPAL=operator-local`. Токен не пишіть у shell history: передайте через середовище своєї сесії/secret manager. Провайдерський API key лишається на сервері.

## Як читати результат

| Результат / exit | Значення |
|---|---|
| `--check`: 0 | JSON-файли й метадані набору структурно валідні; це не перевірка OpenAI |
| `preflight`: 0 | Readiness та caller endpoint доступні; модельний маршрут не перевірено |
| `FAIL`: 1 | Фактична відповідь суперечить клієнтському очікуванню |
| `BLOCKED`: 2 | Немає передумови, маршруту або транспорту; висновку про guardrail немає |
| `OBSERVED`: 3 | Клієнтські assertions виконані, потрібен незалежний доказ Gate/сервісу |

**Свідомий обсяг:** набір не повертає загальне «весь захист PASS» лише за HTTP-відповіддю. Модельна відмова у відповіді HTTP 200 не зараховується як блокування гейтом. Відсутність PII у відповіді не доводить, що PII не пішла до OpenAI. Для фінального висновку потрібна кореляція з аудитом, ledger та незалежними receipts. У `summary.json` завжди явно `security_verified: false`.

Планові відмови модельного входу: auth 401; invalid 400/422; policy 403; body size 413; limits 429; dependency 502/503; deadline 408/504. Очікується JSON `error` object з `message`. 404/405 означає відсутній/непридатний маршрут. Коди можна змінювати лише разом із погодженим контрактом, не для приховування помилки реалізації.

**Факт реалізації:** кожна спроба зберігає request, response, headers, curl status і timing (`http_code`, `time_total`, `time_starttransfer`, `size_download`), а основний runner — `result.json` та підсумок. Файли створюються з `umask 077`; автентифікаційні заголовки — у тимчасовій теці, що видаляється. Запити містять тільки синтетичні дані. Не використовуйте цю теку для реальних клієнтських секретів чи PII. Відповіді не друкуються автоматично в консоль.

## Передумови політик

**Пропозиції приймальних профілів, висока впевненість:** це назви передумов тесту, **не** вже встановлені policy IDs. Runner їх не створює і не активує. Перш ніж запускати `--profile NAME` або окремий case, підготуйте в панелі/операторському API ізольовану політику та зафіксуйте її версію. Не вимикайте production-залежності заради тесту.

| Профіль | Що підготувати |
|---|---|
| `baseline` | Дозволена `OPENAI_MODEL`, достатній бюджет, робочий справжній OpenAI; чутливі контролі не мають блокувати нейтральний текст |
| `body-limit` | Ліміт request body нижче 1 200 000 байтів, перевірка до зовнішніх викликів |
| `pii-redact` / `pii-block` | Однакові PII-детектори; дія redact або block; redact виконується до кожного зовнішнього модельного виклику |
| `secret-block` | Блокування синтетичного `sk-…` на вході, до зовнішнього semantic/provider hop |
| `output-redact` | Перевірка виходу, включно з усіма SSE deltas, за email-canary; підтверджений сирий canary на виході провайдера |
| `output-block` | Чутливий upstream-вихід блокується HTTP 403 до SSE: proxy перевіряє повну відповідь перед видачею буферизованого потоку. D07 validator також допускає terminal error, але ця гілка не описує поточний proxy |
| `semantic-strict` | Справжній AI-детектор, зафіксовані model/instruction version/threshold; позитивний контроль S03 також обов'язковий |
| `semantic-unavailable` | Обов'язковий детектор недоступний в ізольованому стеку; fail closed без target dispatch |
| `signature-feed` | Активний фід містить `pickle.loads(`, `os.system(` і синтетичний маркер `GATE_TEST_UNTRUSTED_MODEL_LOADER_V1`; записати hash/version |
| `budget-zero` | Нуль доступних токенів; резерв неможливий до платного виклику |
| `output-cap` | Жорстка відмова для `max_output_tokens: 4096`; cap нижчий за 4096. Якщо продукт обирає clamp, потрібен інший погоджений assertion |
| `deadline-zero` | Серверний deadline вичерпано до dispatch; не підміняти клієнтським curl timeout |
| `money-zero` | Ledger/cap налаштований; нуль allowance. Конфігурований costMicroPerToken є внутрішньою оцінкою, не тарифом або рахунком провайдера |
| `rate-exhausted` | Вікно rate limit для тестового caller уже вичерпано без платного flood |
| `provider-unavailable` | У тестовому стеку заблокований мережевий шлях до справжнього OpenAI; LLM stub не використовується |
| `provider-key-missing` | Ключ відсутній тільки в ізольованій конфігурації; не змінювати справжній збережений ключ |
| `audit-unavailable` | Недоступне durable audit-сховище ізольованого стеку; поведінка до/після dispatch розрізняється доказами |
| `feed-before` / `feed-after` / `feed-rollback` | Маркер `GATE_TEST_LIVE_FEED_V1` спочатку відсутній, потім доданий і активований, потім rollback новою generation |
| `mcp-baseline` | Опублікований MCP-каталог, principals, baseline за [MCP tool contracts](../../app/contracts/mcp-tool-contracts.md): внутрішній Outbox дозволений, зовнішній заборонений, KB-9000 захищений |
| `mcp-semantic-strict` | MCP-вихід проходить справжню семантичну перевірку; KB-INJECT-01 блокується |

**Межа тверджень:** X01–X03 перевіряють передавання й застосування конкретних сигнатур. Вони не доводять покриття всіх exploit-варіантів, CVE або supply-chain атак. Семантичні очікування — запропоновані мітки, не виміряна точність; варіативність реальної моделі може спричинити FAIL, її не приховуємо повторенням до успіху.

## Послідовності

**Пропозиція порядку репетиції:** L01 → A01/A02 → D01/D02 → S01/S03 → X01/X04 → B01 → M02/M04/M06 → agent loop → report. Запускайте профілі після підготовки відповідної політики. `--profile baseline` також включає негативні auth/schema/model cases з базовими передумовами, тому не є одним дешевим smoke-запитом; для smoke використовуйте L01.

- **Зміна порога:** D01 у `pii-redact`, потім D02 у `pii-block`; підтвердити різні активні версії, збереження попереднього snapshot у запиті in-flight та незалежні dispatch counts.
- **Фід наживо:** P01, зміна фіда/активація, P02, rollback, P03; однаковий промпт, нові виклики. Перезапуск застосунку не повинен бути потрібний.
- **Агентський цикл:** `agent-loop.sh KB-1042`; максимум два модельні запити й один MCP read. Отриманий `function_call` перевіряється проти allowlist; відповідь інструмента і всі model output items повертаються з правильним `call_id`. Невідомий інструмент або аргументи не виконуються. Додаткові варіанти — `KB-PII-01` і `KB-INJECT-01`. Модель може отримати відмову інструмента; це також справжній результат, який передається їй.
- **Повтор мутації:** `retry.sh`; однаковий key і тіло, потім той самий key зі зміненим тілом. Потрібен незалежний count Outbox: рівно один ефект. Ідемпотентність цього MCP-розширення не приписується OpenAI Responses.
- **Конкурентний бюджет:** `concurrent-budget.sh`; перед запуском встановити залишок, достатній рівно для одного резерву L01 (включно з semantic/output reserve), виконання інших caller зупинити. Два паралельні запити, очікувано 200+429. Ledger має довести відсутність overspend; самі коди цього не доводять.
- **Звітність:** `report.sh`; однакове часове вікно для summary та всіх сторінок аудиту. Окремо повторити від `support-agent` і переконатися, що немає чужих записів. Модельні виклики мають invocation ID і очищений аудит; поверхні та scope описані в [reporting contract](../../app/contracts/reporting.md). Перевіряйте фактичну кореляцію, а не лише успішний експорт.

## Докази, які потрібно додати з боку Gate

**Пропозиція приймального checklist, висока впевненість:** для кожного control-case зафіксувати кореляцію client request → Gate invocation → provider request/MCP operation, principal, policy release/generation, feed hash, рішення/reasons і статус семантики. Для block — відсутність відповідного dispatch; для redact — перевірка очищеного payload на мережевій межі, включно з семантичним провайдером; для output-redact — сирий upstream справді містив canary. Сирі payload зберігати лише для цих синтетичних fixtures, ключі й Authorization не експортувати.

Для budget cases потрібні used/reserved/remaining до та після, target і semantic usage окремо, облік unknown usage після timeout. Для мутацій — service receipt та незалежний стан. Для performance — розділити Gate overhead і latency OpenAI; curl `time_total` є тільки end-to-end виміром і не доводить накладні витрати proxy. Поточний набір не підробляє ці докази і не генерує «успішний» sidecar замість них.

## Додаткові заплановані сценарії та наявний приймальний suite

[Матриця покриття](../../docs/23-bash-scenario-matrix.md) зв'язує цей набір із розділами завдання організаторів. Для lifecycle/відмов із керуванням контейнерами використовуйте наявний `make demo-mcp-test`: він запускає ізольований Compose-проєкт за замовчуванням. Не підміняти його одиночним curl. Не встановлюйте `DEMO_MCP_TEST_IN_PLACE=1` для звичайної репетиції.

Перед поданням потрібно окремо закрити: reset/reconcile/fence, crash recovery, version conflicts, власність ресурсів, schema drift, compare/activation CAS, rollback, audit sanitization/pagination/own-scope, invalid feed, Redis/DB failure. Наявність сценарію/коду тесту не означає його проходження в поточному стані.

## Перевірка самого набору

### Мануальні сценарії оператора панелі

**Факт реалізації:** `operator-panel.sh` доповнює браузерну перевірку локальними
синтетичними викликами `/v1/panel/invoke`. Не викликає OpenAI й не змінює політики.
Політику готують у браузері. Результати цього прогону та межі —
звіт оператора (archive reference: `../../sources/operator-manual-report-2026-10-04.md`).

```bash
# RESULT_DIR має бути новим або порожнім.
RESULT_DIR=/tmp/operator-panel-new bash scripts/gate-scenarios/operator-panel.sh suite
RESULT_DIR=/tmp/operator-panel-pair OPERATOR_CASES=false-positive,injection,exception-reuse \
  bash scripts/gate-scenarios/operator-panel.sh suite
RESULT_DIR=/tmp/operator-panel-state bash scripts/gate-scenarios/operator-panel.sh state
```

**Межа:** suite потребує імпортованого `qa_operator_documents` для qa-* fixtures;
без нього виберіть наявні cases через `OPERATOR_CASES`. Exit 0 означає успішний
HTTP-транспорт, не verdict захисту. Зіставляйте `policy.version`, `r.decision`,
`action.dispatched`, `action.outcome` та `output.disclosure` з конкретною політикою.
Створюються знімки стану до/після та окремі request/response/timing для кожного case.

```bash
for file in scripts/gate-scenarios/*.sh; do bash -n "$file"; done
python3 -m unittest discover -s scripts/gate-scenarios -p test_assertions.py
./scripts/gate-scenarios/run.sh --check
```

**Межа:** локальні unit-тести перевіряють валідатор на коротких штучних JSON-об'єктах. Це не HTTP-сервіс, не fallback генерації й не емуляція провайдера в демо.

**Факт конфігурації перевіреного запуску:** fixtures використовують до 1024 output tokens (B02 — 4096). `OPENAI_REASONING_EFFORT` необов’язково задає effort для агентського циклу; `minimal` перевірено з наведеною nano-моделлю. Іншим моделям можуть бути потрібні інші значення. Початкова активація моделі й часових вікон описана в [контракті](../../app/contracts/model-proxy.md#operator-setup-and-verification).
