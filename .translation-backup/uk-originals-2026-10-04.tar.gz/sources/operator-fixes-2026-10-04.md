# Виправлення операторської панелі — 2026-10-04

**Факт доручення:** власник попросив повністю прочитати мануальний звіт (archive reference: `operator-manual-report-2026-10-04.md`) та імплементувати всі фікси. Обсяг цієї сесії — шість дефектів UI-01–UI-06 із таблиці звіту. Описані там продуктові межі (нові principals, MCP delete, зовнішній signature feed, production RBAC) не перетворено на додаткові доручення.

## Реалізація та докази

Наведені нижче результати — **факти реалізації й перевірки**, а не оцінка повної готовності продукту.

| Дефект | Виправлення | Перевірка |
|---|---|---|
| UI-01 | Незмінний refresh зберігає посилання на об’єкти draft/tests, якими користуються обробники форм. Зовнішня зміна перемальовує відповідний редактор | Браузер: refresh → Secrets Block, token limit 1, Who, Name/Type → серверне збереження |
| UI-02 | Compare оцінює UTF-8 input tokens так само, як invoke; враховує fixture counters. Нові події зберігають evaluationContext, Save as test case переносить його у fixture. Є поле tokens already used | Ліміт 1: live policy Allow → candidate Throttle; після активації Throttle. Окрема регресія відтворює вже використані 1 000 000 токенів без витрати live counters |
| UI-03 | not_started не показує processed як отриманий payload; content-only input явно позначає відсутність model dispatch | Браузерний скриншот Throttle (archive reference: `operator-fixes-2026-10-04/browser/08-throttle-no-received-payload.png`): нічого не отримано, not_started, Dispatched No |
| UI-04 | Unified report у панелі: однакове вікно для panel/MCP/model/legacy, пошук ID/agent/target, metadata/receipts, NDJSON export. GET /v1/report та summary.unified використовують ту саму проєкцію. Старі audit endpoints включають збережені panel/MCP операції | Звірка (archive reference: `operator-fixes-2026-10-04/verification.json`): усі 42 panel ID та 5 MCP ID зі звіту знайдено в summary й export. Перевірено ownership, фільтри, пагінацію без дублів та прив’язку курсора до вікна/фільтра |
| UI-05 | Requests search включає повний request ID | Браузер: пошук ID знаходить потрібну подію |
| UI-06 | Виняток — case-insensitive рівність усього тексту, а не contains; UI пропонує повний текст і пояснює правило | Точна навчальна фраза Allow; фраза + дописана атака Block; інші checks не вимикаються |

**Факт перевірки:** 296 автоматизованих тестів: 275 unit/HTTP + 21 PostgreSQL (archive reference: `operator-fixes-2026-10-04/unit-http.log`), 21 PostgreSQL-тест (archive reference: `operator-fixes-2026-10-04/postgres.log`), 58 браузерних перевірок (archive reference: `operator-fixes-2026-10-04/browser.log`) — OK. PostgreSQL suite створює окрему scratch database; браузер працював із чистим memory backend. Тестові активації браузера не змінювали політики основного демостека.

**Факт перевірки історичних даних:** денний summary (archive reference: `operator-fixes-2026-10-04/report-day/management/response.body`) містить 434 операції: 42 panel, 361 MCP, 15 model, 16 legacy. Повний export цього ж вікна містить 697 audit rows: кількість audit rows не дорівнює кількості операцій. Вікно `2026-10-03T22:00Z`—`2026-10-04T22:00Z` відповідає оригінальному QA; його кінець був майбутнім, тому це знімок на момент читання, а не підсумок завершеного дня. Перший 15-хвилинний звіт не містив старих QA-подій; звірку повторено в правильному денному вікні.

**Факт стану:** локальні `api` і `gate-mcp` оновлено. Стан (archive reference: `operator-fixes-2026-10-04/runtime-state.json`): policy v21, draft = live, 43 panel events загалом, 7 synthetic effects. SHA-256 політики збігається зі збереженим станом після попереднього QA. Дані та історію не скидали. Нових платних модельних викликів не виконували.

## Межі

- **Факт контракту:** існуючі `exceptions[].match` тепер трактуються як повний текст. Старий короткий contains-виняток може перестати пропускати довший запит; це навмисне звуження винятку.
- **Факт контракту:** compare — незалежні fixtures із зафіксованим контекстом. Він не прогнозує майбутнє навантаження. Старі події без evaluationContext не отримують вигаданих історичних counters.
- **Факт контракту:** synthetic estimated tokens та provider reported tokens показано окремо за агентом/моделлю; відсутній usage позначено. Це не грошовий invoice провайдера.
- **Факт контракту:** audit додає один outcome snapshot на panel/MCP операцію, а не повну історію MCP transitions. Receipt IDs доступні для дослідження; новий workflow reconcile/fence через UI не додавався.
- **Неперевірене:** навантаження, paging під конкурентними записами, production RBAC, trained semantic quality, нові інжектовані unknown/reconcile. Поточний merger завантажує записи вибраного вікна в пам’ять; результати різних сховищ не є єдиним транзакційним snapshot.

Код: [panel.js](../app/static/control/panel.js), [panel service](../app/action_gate/panel_service.py), [engine](../app/action_gate/panel_engine.py), [уніфікована звітність](../app/action_gate/operator_reporting.py). Контракти оновлено в [control panel](../app/contracts/control-panel.md) і [reporting](../app/contracts/reporting.md).
