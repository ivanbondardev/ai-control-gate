# _inbox — сирі файли з описом завдання Goldman Sachs

Класти файли **як є**, без перейменування вмісту й без редагування: PDF, скріншоти, експорти з платформи, нотатки з брифінгу, листи організаторів.

Імена: `YYYY-MM-DD-<джерело>-<коротка назва>.<розширення>`, де джерело — `hackyeah`, `goldman`, `platform`, `organizer` або `mentor`.

| Файл | Джерело | Отримано | Що це |
|---|---|---|---|
| [CRIETRIA AI Control Layer.pdf](<CRIETRIA AI Control Layer.pdf>) | goldman | 2026-10-03 11:33 | Опис завдання: контекст, проблема, очікувані артефакти, формальні й технічні вимоги, підхід до тестування, критерії |
| [RULES AI Control Layer.pdf](<RULES AI Control Layer.pdf>) | goldman | 2026-10-03 11:32 | Правила конкурсу: організатор, призи, строки, вимоги до подання, два етапи оцінювання, критерії |

Обидва конвертовано в Markdown у [../extracted/](../extracted/README.md) — англійською та українською. Розбір: [../notes/task-analysis-2026-10-03.md](../notes/task-analysis-2026-10-03.md).

**Що ще варто добрати в `_inbox/`:** повідомлення організаторів про дедлайн (розбіжність «11:00 PM», див. розділ 6.1 розбору), форму подання на HackTribe, скріншот картки треку, оголошений склад журі з Discord.

Для текстових файлів — шапка:

```markdown
---
title: ...
source: task-card | briefing | platform | email | screenshot | mentor
obtained: 2026-10-03
origin: <URL або «наживо на події»>
language: en | pl | uk
verbatim: true | false
---
```

Детально: [../README.md](../README.md).
