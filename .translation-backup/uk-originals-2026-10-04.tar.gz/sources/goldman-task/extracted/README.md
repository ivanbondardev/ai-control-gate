# extracted — текст, витягнутий із сирих файлів

Заповнено 2026-10-03. Обидва PDF конвертовано в Markdown — англійською (текст оригіналу) і українською (неофіційний переклад).

**Основні першоджерела завдання від організаторів:** чотири документи нижче, за визначенням власника від 2026-10-03. Англійські файли — витяги з оригінальних PDF, українські — їхні неофіційні переклади. Для точних формулювань звірятися з англійським текстом і PDF.

| Файл | Що це |
|---|---|
| [CRIETRIA AI Control Layer.md](CRIETRIA%20AI%20Control%20Layer.md) | Опис завдання англійською, текст оригіналу |
| [CRIETRIA AI Control Layer.uk.md](CRIETRIA%20AI%20Control%20Layer.uk.md) | Український переклад завдання й критеріїв |
| [RULES AI Control Layer.md](RULES%20AI%20Control%20Layer.md) | Правила конкурсу англійською, текст оригіналу |
| [RULES AI Control Layer.uk.md](RULES%20AI%20Control%20Layer.uk.md) | Український переклад правил |

**Конвертацію виконав власник, точність перевірено.** Ключові твердження звірено з PDF незалежно — розбором потоків PDF і таблиць `ToUnicode` (разовий скрипт, у репозиторії не зберігається). Збіглися: «11:00 PM» для обох дат, «maximum 10-slides PDF presentation», «in English or Polish», ваги критеріїв в обох документах (30/20/20/20/10 і 30/20/20/15/15), «Block vs Redact», «token spend», «signatures … fed from some externally managed system», «local models (such as those run via Ollama)». Деталі — в [../notes/task-analysis-2026-10-03.md](../notes/task-analysis-2026-10-03.md).

Довгі абзаци слід читати повністю з файлу; скорочений вивід інструмента не є скороченням першоджерела.

Правило: один витягнутий файл відповідає одному файлу з `_inbox/`, назва збігається, а в шапці стоїть посилання на джерело:

```markdown
---
title: ...
from: ../_inbox/2026-10-03-hackyeah-task-card-goldman.pdf
method: pdf-text | ocr | manual-notes | translation
extracted: 2026-10-03
fidelity: exact | ocr-uncertain | paraphrase | translation
---

<текст>
```

`fidelity: ocr-uncertain` — обов'язково для OCR зі скріншотів: цифри дедлайнів, суми призів і мовні вимоги з такого тексту не цитуються без звірки з оригіналом.
