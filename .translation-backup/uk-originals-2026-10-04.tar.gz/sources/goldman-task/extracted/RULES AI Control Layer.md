---
source: organizer-task
source_role: primary-reference
source_confirmed_by: owner
title: "RULES AI Control Layer"
from: "../_inbox/RULES AI Control Layer.pdf"
method: pdf-text
extracted: 2026-10-03
fidelity: exact
---

**Основне першоджерело завдання від організаторів — статус визначено власником 2026-10-03.** Цей файл є англійським текстовим витягом із PDF організаторів; оригінальний PDF вказано нижче.

Джерело: [RULES AI Control Layer.pdf](<../_inbox/RULES AI Control Layer.pdf>). Текст оригіналу; переноси рядків і форматування адаптовано до Markdown. Помилки та розбіжності джерела збережено.

<!-- Сторінка 1 -->

# Terms and conditions of the "AI CONTROL LAYER" Competition

1. These terms and conditions (hereinafter referred to as Terms) stipulate the rules and conditions of the "AI Control Layer" Competition in a hackathon event HackYeah and are an annex to the general terms and conditions of HackYeah Hackathon.

2. The Hackathon Sponsor and promising the prize within the meaning of art. 921 § 3 of the Civil Code (Journal of Laws 2017, item 459) is Proidea Sp. z o.o., with registered office in Kraków 30-418, ul. Zakopiańska 9, registered under numbers: NIP (Taxpayers ID no): 6793088842 and REGON (Business ID no): 122769022, entered into KRS (National Court Register) under number 0000448243, which may be reached at biuro@proidea.org.pl.

3. Details of the task will be presented at the start of the competition.

4. Prizes in Competitions organized by the Organizer will be issued within 90 days from the announcement of results, unless otherwise specified in the respective Competition rules.

5. Participation in the "AI Control Layer" Competition may be taken individually and in teamsof up to six people who have started solving the competition task no earlier than11:00 PM on October 3rd and forwarded the task for evaluation no later than 11:00PM on October 4th. The task submitted for evaluation must include:

a) project title

b) name of the team

c) list of team members (1-6 members)

d) project description

e) maximum 10-slides PDF presentation and could include: snapshots, code repository, demo links, graphic materials and other materials related to the project or suggested in the detailed task description. The task solutions should be submitted to platform HackTribe in English or Polish.

<!-- Сторінка 2 -->

6. Participants related to or affined with members of the "AI Control Layer" Competition Jury and employees promising the prize are excluded from participation.

7. The total prize pool in the competition is PLN 15,000 (including tax), divided as follows:

- 1st place: PLN 6,000 (including tax)

- 2nd place: PLN 5,000 (including tax)

- 3rd place: PLN 4,000 (including tax)

8. The goal of the Competition is to present the solutions to the problem - an open task. The solutions of respective tasks will be evaluated in 2 phases:

a) phase 1 - evaluation of submitted projects on the HackTribe platform by a commission appointed for the specific task, consisting of at least three Mentors.

b) phase 2 - evaluation of live presentations delivered by the finalists to a Jury. The presentations (pitching) will be made by the teams chosen in phase 1. It is emphasized that the members of the evaluation commission in phase 1 and the Jury in phase 2 may coincide, but they are not obligated to be the same individuals.

9. The members of the Jury will select a chairman from among themselves.

10. In the event of an equal number of votes, the Jury's vote shall decide in both phases.

11. Judging criteria are as follows:

- Robustness of the Solution and Quality of Guardrails - 30%

- Architecture and Performance Efficiency - 20%

- Security Reporting - 20%

- Completeness of the Self-Testing Suite - 20%

- Practical Implementability and Scalability - 10%

12. In order to receive the award, the project must receive a minimum of 50% of the points in 1 step. Jury and Jury members' decisions are final and cannot be appealed.

<!-- Сторінка 3 -->

13. Any alterations or revisions made after the statutory time is expired are illegal. Any alterations and modifications made after the statutory time is expired will not be considered by the Jury.

14. The author's proprietary copyrights to the awarded solution will not be transferred to the Competition Sponsor.

15. Jury members will be posted on the HackYeah communication platform (Discord) no later than October 4th.
