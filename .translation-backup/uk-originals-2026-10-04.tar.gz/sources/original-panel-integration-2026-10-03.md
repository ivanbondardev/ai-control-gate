# Оригінальний frontend і серверні сценарії — 3 жовтня 2026

## Доручення і виправлення обсягу

**Факт джерела — пряме доручення власника в цій сесії:** «так. взяти оригінальний фронтенд за основу й реалізувати відсутні серверні можливості під його сценарії».

Це підтвердження заміни попереднього звуженого варіанта, описаного у попередньому звіті (archive reference: `frontend-integration-2026-10-03.md`). Попередні 68 браузерних перевірок не були доказом паритету. Чинний результат описано нижче.

## Що реалізовано

**Факти вихідного коду та виконаних перевірок:**

| Сценарій оригінального UI | Серверна реалізація |
|---|---|
| Бібліотека перевірок, додавання, редагування, вимкнення, порядок pipeline | Оригінальна схема checks; спільний evaluator для compare та runtime |
| YAML↔форми, імпорт/експорт | Локальний js-yaml, файл → спільна серверна чернетка; активація окрема |
| Правила за агентом, сервісом, дією та умовами параметрів | Умови, specificity, block при рівній специфічності, default reaction |
| Візуальні тест-кейси й fault injection | Збережений корпус, серверні live/candidate результати; test-only faults не дозволяють активацію |
| Impact, активація, історія, rollback | Зв'язана з candidate/tests/registry/version evidence, CAS, нова версія при rollback |
| Зовнішня зміна політики під час редагування | Polling фактичного серверного стану, rebase або прийняття нового active |
| Імпорт і перевірка сервісів | Typed schema у PostgreSQL, локальна перевірка, endpoint лише metadata |
| Запуск запиту й деталі | Серверний admission → локальна дія → вихідні перевірки → очищений журнал |
| False-positive review, exception, save-as-test, replay | Збережений review, версійований виняток через compare, sanitized replay без dispatch |
| Training review та JSONL | Приклади фактичних baseline evaluations, людське підтвердження/корекція, експорт reviewed |

Код: [frontend](../app/static/control/panel.js), [HTML/CSS](../app/static/control/index.html), [evaluator](../app/action_gate/panel_engine.py), [lifecycle/runtime](../app/action_gate/panel_service.py), [міграція](../app/migrations/0004_control_panel.sql). Англомовний [контракт API](../app/contracts/control-panel.md).

**Факт збереження оригіналу:** вкладений Git clone `ai-control-layer/` на `fbf4c03` не має локальних змін. Інтегрована копія компонентів розташована в `app/static/control/`. Стилі адаптовано також до ширини in-app browser, щоб бібліотека не відсувала весь pipeline нижче першого екрана.

## Семантика й межі

**Факт реалізації:** `/v1/panel/*` працює в тому самому HTTP-застосунку й PostgreSQL, але має окрему оригінальну схему політики. Її виконує `/v1/panel/invoke`. Старі `/v1/invocations` і `/v1/config/*` зберігають попередню політику та developer workbench. Активація в новому конструкторі не перемикає старий gateway; старі records не змішуються з новою панеллю.

**Факт реалізації:** один transactional state row забезпечує атомарність активації, admission, локального ефекту, журналу та idempotency claim. Стан обмежений 32 MB й окремими лімітами колекцій; перевищення повертає 413 і відкочує мутацію. Автоматичного очищення/архівації немає. PostgreSQL bootstrap додає початкові 11 checks, 10 rules, 6 services, 12 tests; events/training порожні.

**Факт межі:** усі адаптери синтетичні. Documents підтримує локальні read/search/update/delete; інші дії мають явний синтетичний результат і запис ефекту. Реальних сторонніх систем не викликали. Throttle — відмова admission із retry-after, без прихованого sleep/queue. Токени — підписана оцінка, не provider usage.

**Факт межі:** semantic checks — детермінована baseline. Поля model/instruction зберігаються, instruction_version контролює сервер, але довільні інструкції не виконуються моделлю. Кеш, модельні токени й зовнішній signature feed не імітуються. Секрети/PII очищуються перед baseline незалежно від порядку pipeline. Regex обмежений безпечним піднабором і максимумом 64 patterns; бюджет локального оцінювання 1000 мс завершується відмовою, неповне compare не дозволяє activation.

**Факт перевірки стандартних прикладів на PostgreSQL:** 11/12 відповідають заданим очікуванням. `Security training question` є відомим false positive baseline: очікується allow, фактично block. Це лишено видимим; браузерний сценарій перевіряє його review/exception. Ці fixtures не є holdout-набором і не доводять якість захисту.

**Факт межі:** replay працює з очищеним збереженим вмістом, без сервісних ефектів і відтворення старих rate counters. Імпорт YAML не створює watcher на серверній файловій системі. Training export не навчає модель. Неперевірені навантаження, продукційна автентифікація/TLS, реальні model/service adapters, повна матриця мобільних браузерів і crash injection PostgreSQL.

## Перевірки та запуск

**Факти фінальних прогонів:**

| Перевірка | Результат | Доказ |
|---|---|---|
| Python 3.11 unit/HTTP | 211 знайдено, 191 успішних, 20 DB integration пропущено | unit.log (archive reference: `original-panel-checks-2026-10-03/unit.log`) |
| PostgreSQL scratch DB | 20 успішних; persistence, draft CAS, 6 конкурентних invoke → один ефект, 2 activation → один переможець | postgres.log (archive reference: `original-panel-checks-2026-10-03/postgres.log`) |
| Chrome, ізольований memory backend | 50 успішних перевірок оригінальних сценаріїв; без JS exceptions | browser.log (archive reference: `original-panel-checks-2026-10-03/browser.log`) |
| Docker build/migration/readiness | API healthy, PostgreSQL durable, Redis ready | deploy.log (archive reference: `original-panel-checks-2026-10-03/deploy.log`), ready.json (archive reference: `original-panel-checks-2026-10-03/ready.json`) |
| In-app browser → Traefik → PostgreSQL | Підключення operator, оригінальний builder, серверний запуск 12 fixtures | скриншот (archive reference: `original-panel-checks-2026-10-03/08-live-postgres.png`) |
| JS syntax, git diff --check, чистота clone | Успішно | локальні команди сесії |

**Факт методики:** lifecycle/зміни правил/виклики браузерного прогону ізольовано на `127.0.0.1:18082`; DB-тести використовують і видаляють scratch `action_gate_integration`, не основну БД. У головній панелі запущено compare початкового корпусу без activation або service dispatch. Старий gateway лишився на generation 26. Платних модельних викликів у цій сесії не було.

Повторення: свіжий memory backend без `.env`, dedicated Chrome із debugging port 9229, `make control-ui-check`. Сценарій [panel-ui-check.js](../scripts/panel-ui-check.js) відмовляється працювати з durable/provider-backed або непорожнім сервером.

Локальний результат: [відкрити конструктор](http://ai-control-proxy.localhost/control/#/builder/checks). Контейнери залишено працювати; тимчасові memory server і headless Chrome зупинено після перевірок.
