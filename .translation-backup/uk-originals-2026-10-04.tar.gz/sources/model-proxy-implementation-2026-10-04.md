# Реалізація модельного proxy — 2026-10-04

**Факт доручення:** після перевірки відсутнього маршруту власник доручив «реалізуй». Раніше прямо доручено реальні запити до OpenAI з наданим серверним ключем і Bash-клієнти з localhost. Це дозволяє реальну інтеграцію в межах цього завдання; ключ не додавався в код чи fixtures. Попередня перевірка (archive reference: `model-proxy-check-2026-10-04.md`), [формат і провайдер](openai-request-format-decision-2026-10-04.md).

**Факт реалізації:** `POST http://localhost/v1/responses` передає дозволені запити до `https://api.openai.com/v1/responses`. Реалізовано текст, історію, function calling, stateless reasoning continuation та буферизований SSE. Ключ читається лише сервером. Контролі входу/виходу, allowlist, атомарний резерв бюджету, облік usage та очищений аудит виконуються на Gate. [Контракт і межі](../app/contracts/model-proxy.md), [реалізація](../app/action_gate/model_proxy.py).

**Факт активації:** API-образ перебудовано й запущено зі збереженням даних; `gpt-5-nano-2025-08-07` додано через compare/activate панелі (version 16). Нових comparison failures немає; попередній baseline mismatch `t10` залишено явно позначеним. Окремим compare/activate конфігурації (generation 30) збільшено часові вікна: target 15000 ms, output 4000 ms, global 20000 ms; денні ліміти збережено. Активація моделі (archive reference: `../evidence/model-proxy-2026-10-04/activation.json`), часові вікна (archive reference: `../evidence/model-proxy-2026-10-04/deadline-activation.json`), [операторський helper](../app/action_gate/model_proxy_setup.py).

## Перевірки

**Факт автоматизованої перевірки:** фінальний образ пройшов 290 тестів, включно з HTTP і справжнім PostgreSQL. Лог (archive reference: `../evidence/model-proxy-2026-10-04/final-tests.log`). Підміна транспорту використовується лише для ізольованих unit-тестів; runtime працює з OpenAI.

**Факт живих перевірок:** з localhost пройшли клієнтські assertions L01/L02/L03/L04, A01–A04, V01–V03, D01 та D03; L02 і D01 — після виправлень, а не в першому прогоні. Окремо пройшов цикл OpenAI → MCP documents read → OpenAI. Статус `OBSERVED`/exit 3 означає успішні клієнтські assertions, що потребують серверних доказів; його не перейменовано на повне security-підтвердження.

| Вибрана перевірка | HTTP | Реальні total_tokens OpenAI |
|---|---:|---:|
| L01, текст | 200 | 168 |
| L02, історія | 200 | 421 |
| L04, SSE | 200 | 133 |
| A04, заборонена модель | 403 | dispatch відсутній |
| D01, очищення синтетичних PII | 200 | 907 |
| D03, блокування синтетичного секрету | 403 | dispatch відсутній |
| Агентський цикл, перший виклик | 200 | 217 |
| Агентський цикл, завершення | 200 | 633 |

**Факт незалежної звірки:** для восьми рядків таблиці аудит отримано через `/v1/invocations/{id}` і зіставлено з клієнтськими invocation IDs. Успішні виклики мають provider request/response IDs, usage та budget commit; A04/D03 не мають dispatch. D01 має `inputRedacted=true` і відмінні хеші вхідного та переданого payload. Це аудит обробки, не мережеве захоплення; sanitized outgoing payload окремо перевірений unit-тестом. Зіставлені докази (archive reference: `../evidence/model-proxy-2026-10-04/verified-audit.json`).

Живі артефакти: основний прогін (archive reference: `../evidence/gate-scenarios/20261003T235931Z-54065-14928/`), L02 (archive reference: `../evidence/gate-scenarios/20261004T000339Z-55260-8039/L02/`), D01 (archive reference: `../evidence/gate-scenarios/20261004T000412Z-55411-24411/D01/`), D03 (archive reference: `../evidence/gate-scenarios/20261004T000418Z-55489-15069/D03/`), агентський цикл (archive reference: `../evidence/gate-scenarios/20261004T000248Z-55003-20986/`).

**Факт знайдених і виправлених проблем:** реальний транспорт виявив закриття HTTP stream після останнього Content-Length chunk; додано регресійний тест. Реальний reasoning item містить `content: []`; додано підтримку та тест. 256 output tokens іноді давали `incomplete`, тому fixtures тепер мають 1024 (бюджетний B02 — 4096); занадто коротке target-вікно збільшено через активацію вище. Попередні невдалі артефакти збережено. Timeout/невідоме usage обліковуються консервативно, не як безкоштовний виклик.

## Межі підтвердження

**Факт поточної реалізації:** підтримується обмежений Responses-профіль, не весь OpenAI API; медіа, hosted tools, persistent context і Chat Completions відсутні. SSE видається після повної перевірки відповіді. Семантичний детектор за замовчуванням залишається позначеним baseline; реальна генерація не доводить якість AI-захисту. Політика панелі й legacy config фіксуються окремо, не є одним атомарним релізом. Model allowlist глобальний для автентифікованих principals, без окремих model grants. Вартість у бюджеті — конфігурований консервативний allowance, не тариф/рахунок OpenAI. Crash reservations утримуються без автоматичного reconcile. Encrypted reasoning непрозорий для контентних перевірок. Деталі — у [контракті](../app/contracts/model-proxy.md).

**Неперевірене:** усі 53 сценарії під усіма потрібними policy profiles, повна якість захисту, навантаження та production readiness. Описані живі перевірки не замінюють цих перевірок.
