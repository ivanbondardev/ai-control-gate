# Карта документації Action Gate

Оновлено після очищення 2026-10-04. У воркспейсі 50 документальних файлів: 45 Markdown, 2 PDF, 2 JSON-індекси та 1 лог. Початкова інвентаризація охоплювала 46 файлів; додано карту, звіт очищення, індекс pitch та архів попереднього judging.

Три pitch-чернетки перенесено до датованого архіву; робочі довідники оновлено. Статус «зберегти» означає роль документа, а не нове підтвердження runtime. Виконані C01–C10 — у [звіті очищення](09-documentation-cleanup.md).

## Порядок читання

1. [Головний README](../README.md) → [правила роботи](../AGENTS.md) → [межі перенесення](transfer.md).
2. Для розробки: [README застосунку](../app/README.md) → [контракти](../app/contracts/README.md) → відповідний код і тести.
3. Для перевірок: [сценарний клієнт](../scripts/gate-scenarios/README.md) → [матриця сценаріїв](23-bash-scenario-matrix.md). Матриця відділяє опис сценарію, історичний доказ та перевірку цієї копії.
4. Для конкурсу: [реєстр першоджерел](../sources/goldman-task/_inbox/README.md) → [витяги](../sources/goldman-task/extracted/README.md) → [критерії](05-judging.md) → [питання](07-open-questions.md). Історичну оцінку продукту не приймати за поточну.
5. Для продовження роботи: [рішення](01-decision.md), [журнал](08-session-log.md), [операторські сценарії](25-gate-operator-scenarios.md).

## Як трактувати джерела

- Вимоги конкурсу: оригінальні PDF і англійські витяги; українські переклади допоміжні. Розбіжності строків і ваг залишаються в журналі питань. У цьому огляді PDF не перевитягували й переклади не звіряли повторно.
- Реалізація: код і тести відповідного шляху; контракти описують очікувану поведінку. У цій сесії runtime не запускався.
- Звіти в `sources/`: докази конкретних попередніх прогонів. Вони не засвідчують працездатність нового середовища.
- Сценарії й pitch: бажана поведінка або історичні чернетки; статус зазначено для кожного документа.

## Повний реєстр після очищення

### Вхід і походження

| Файл | Призначення | Статус / дія |
|---|---|---|
| [README.md](../README.md) | Головний вхід, запуск, межі копії | Зберегти |
| [AGENTS.md](../AGENTS.md) | Правила роботи у воркспейсі | Зберегти |
| [CHANGELOG.md](../CHANGELOG.md) | Історія релізів 0.0.1–0.2.0 | Історія; не переписувати |
| [TRANSFER-MANIFEST.json](../TRANSFER-MANIFEST.json) | SHA-256 початкового складу перенесення | Доказ походження |
| [docs/transfer.md](transfer.md) | Склад копії, виключення та перевірки перенесення | Доказ походження |

### Керування проєктом і сценарії

| Файл | Призначення | Статус / дія |
|---|---|---|
| [docs/01-decision.md](01-decision.md) | Журнал рішень | Доповнювати |
| [docs/07-open-questions.md](07-open-questions.md) | Відкриті та закриті питання | Оновлювати за доказами |
| [docs/08-session-log.md](08-session-log.md) | Журнал сесій | Лише додавати |
| [docs/05-judging.md](05-judging.md) | Критерії та історична оцінка готовності | Актуальні критерії; стара оцінка в архіві |
| [docs/23-bash-scenario-matrix.md](23-bash-scenario-matrix.md) | Зв’язок вимог зі сценаріями | Статуси доказів узгоджено |
| [docs/25-gate-operator-scenarios.md](25-gate-operator-scenarios.md) | Вісім запропонованих процесів оператора | Пропозиції; зберегти |
| [docs/archive-references.json](archive-references.json) | Індекс посилань на виключений архів | Початковий знімок походження |

### Технічна документація

| Файл | Призначення | Статус / дія |
|---|---|---|
| [app/README.md](../app/README.md) | Запуск, конвеєр, MCP, обмеження | Робочий довідник |
| [app/docs/structure.md](../app/docs/structure.md) | Карта модулів раннього зрізу 0.2.0 | Карту модулів оновлено |
| [app/contracts/README.md](../app/contracts/README.md) | Індекс HTTP і MCP контрактів | Зберегти |
| [app/contracts/invocation.md](../app/contracts/invocation.md) | Захищений виклик, ідемпотентність, аудит | Заголовок узгоджено з релізом |
| [app/contracts/configuration.md](../app/contracts/configuration.md) | Draft, compare, activate, rollback, bootstrap | Зберегти |
| [app/contracts/control-panel.md](../app/contracts/control-panel.md) | Панель, політика, аудит і операторські виправлення | Зберегти |
| [app/contracts/reporting.md](../app/contracts/reporting.md) | Метрики, ownership, експорт, спільна звітність | Зберегти |
| [app/contracts/mcp-protocol-profile.md](../app/contracts/mcp-protocol-profile.md) | Обраний протокольний і транспортний профіль | Зберегти |
| [app/contracts/mcp-tool-contracts.md](../app/contracts/mcp-tool-contracts.md) | Каталог і схеми синтетичних MCP-інструментів | Зберегти |
| [app/contracts/mcp-operations.md](../app/contracts/mcp-operations.md) | Операції, retry, unknown, reset, докази | Зберегти |
| [app/contracts/model-proxy.md](../app/contracts/model-proxy.md) | Responses proxy, бюджети, SSE, налаштування | Зберегти |
| [app/migrations/README.md](../app/migrations/README.md) | Опис схеми та runner раннього релізу | Узгоджено з SQL і runner |
| [infra/postgres/init/README.md](../infra/postgres/init/README.md) | Початкова ініціалізація PostgreSQL | Узгоджено з SQL і runner |
| [scripts/gate-scenarios/README.md](../scripts/gate-scenarios/README.md) | Інструкція сценарного клієнта й assertions | Статуси доказів узгоджено |

### Звіти реалізації та докази

| Файл | Призначення | Статус / дія |
|---|---|---|
| [sources/original-panel-integration-2026-10-03.md](../sources/original-panel-integration-2026-10-03.md) | Інтеграція оригінальної панелі | Датований звіт |
| [sources/mcp-fixes-2026-10-04.md](../sources/mcp-fixes-2026-10-04.md) | Виправлення MCP і відновлення операцій | Датований звіт |
| [sources/model-proxy-implementation-2026-10-04.md](../sources/model-proxy-implementation-2026-10-04.md) | Реалізація й перевірки модельного proxy | Датований звіт |
| [sources/operator-fixes-2026-10-04.md](../sources/operator-fixes-2026-10-04.md) | Виправлення UI-01–UI-06 | Датований звіт |
| [sources/openai-request-format-decision-2026-10-04.md](../sources/openai-request-format-decision-2026-10-04.md) | Походження вибору формату модельного API | Джерело рішення |
| [sources/export-unit-tests.log](../sources/export-unit-tests.log) | Сирий лог перевірок копії | Зберегти доказ |

### Конкурсні джерела та їхній розбір

| Файл | Призначення | Статус / дія |
|---|---|---|
| [sources/goldman-task/README.md](../sources/goldman-task/README.md) | Вхід до завдання й правила роботи з джерелами | Навігацію оновлено |
| [sources/goldman-task/_inbox/README.md](../sources/goldman-task/_inbox/README.md) | Реєстр отриманих PDF | Зберегти provenance |
| [sources/goldman-task/_inbox/CRIETRIA AI Control Layer.pdf](../sources/goldman-task/_inbox/CRIETRIA%20AI%20Control%20Layer.pdf) | Оригінальний опис завдання | Первинний PDF; зберегти |
| [sources/goldman-task/_inbox/RULES AI Control Layer.pdf](../sources/goldman-task/_inbox/RULES%20AI%20Control%20Layer.pdf) | Оригінальні правила конкурсу | Первинний PDF; зберегти |
| [sources/goldman-task/extracted/README.md](../sources/goldman-task/extracted/README.md) | Походження витягів і перекладів | Повтор усунуто |
| [sources/goldman-task/extracted/CRIETRIA AI Control Layer.md](../sources/goldman-task/extracted/CRIETRIA%20AI%20Control%20Layer.md) | Англійський витяг опису завдання | Зберегти |
| [sources/goldman-task/extracted/CRIETRIA AI Control Layer.uk.md](../sources/goldman-task/extracted/CRIETRIA%20AI%20Control%20Layer.uk.md) | Неофіційний український переклад завдання | Зберегти |
| [sources/goldman-task/extracted/RULES AI Control Layer.md](../sources/goldman-task/extracted/RULES%20AI%20Control%20Layer.md) | Англійський витяг правил | Зберегти |
| [sources/goldman-task/extracted/RULES AI Control Layer.uk.md](../sources/goldman-task/extracted/RULES%20AI%20Control%20Layer.uk.md) | Неофіційний український переклад правил | Зберегти |
| [sources/goldman-task/notes/README.md](../sources/goldman-task/notes/README.md) | Індекс розбору та короткий підсумок | Формулювання уточнено |
| [sources/goldman-task/notes/task-analysis-2026-10-03.md](../sources/goldman-task/notes/task-analysis-2026-10-03.md) | Вимоги й зіставлення зі старим прототипом | Історичний аналіз; межа позначена |

### Історичні тексти пітчу

| Файл | Призначення | Статус / дія |
|---|---|---|
| [pitch/archive/2026-10-03/demo-script.md](../pitch/archive/2026-10-03/demo-script.md) | Трихвилинне демо старого прототипу | Архівовано; не для подання |
| [pitch/archive/2026-10-03/pitch-lines.md](../pitch/archive/2026-10-03/pitch-lines.md) | Варіанти пітчу та цитати | Архівовано; не для подання |
| [pitch/archive/2026-10-03/submission-outline.md](../pitch/archive/2026-10-03/submission-outline.md) | Старий план подання й слайдів | Архівовано; не для подання |

### Документи навігації та архів оцінювання

| Файл | Призначення | Статус / дія |
|---|---|---|
| [docs/00-documentation-map.md](00-documentation-map.md) | Повний реєстр і порядок читання | Ця карта |
| [docs/09-documentation-cleanup.md](09-documentation-cleanup.md) | Звіт виконання та початкові кандидати | C01–C10 виконані |
| [pitch/README.md](../pitch/README.md) | Вхід до історичних pitch-матеріалів | Поточна навігація |
| [docs/archive/2026-10-03/judging.md](archive/2026-10-03/judging.md) | Попередня оцінка старого прототипу | Історія; не оцінка поточної копії |

## Межі охоплення і походження

Скановано звичайні файли воркспейсу, крім `.git`; зовнішній архів не обходили. Код, SQL, конфігурація й fixtures не рахуються окремими документами. Початковий склад: 223 файли, 46 документальних, 652 786 байтів; побайтових дублікатів серед документів не було, 168 локальних Markdown-посилань мали наявні цілі.

Усі 221 записи початкового `TRANSFER-MANIFEST.json` збігалися з SHA-256 до документальних сесій. Маніфест та `archive-references.json` (71 запис із 16 файлів) лишаються початковими знімками, а не актуальними індексами після редакційних змін. Зокрема шляхи `pitch/*.md` у цих JSON тепер відповідають архіву `pitch/archive/2026-10-03/`; старий `docs/05-judging.md` збережено у датованому архіві з виправленими посиланнями.

Перевірки очищення — у [журналі](08-session-log.md). Перевірка локальних посилань охоплює існування файлу/каталогу, не anchors чи зовнішні URL. PDF і переклади повторно не звіряли; runtime не запускався.
