# Критерії оцінювання AI Control Layer

Оновлено 2026-10-04. Вимоги нижче взяті зі збережених [англійських витягів](../sources/goldman-task/extracted/README.md). Ваги й формулювання не є оцінкою готовності Action Gate. Попередню оцінку старого прототипу, дизайн-пропозиції та відповіді журі збережено в [датованому архіві](archive/2026-10-03/judging.md).

## Критерії оцінювання (факт джерела)

| Критерій | RULES, п. 11 | CRIETRIA, розд. 8 |
|---|---:|---:|
| Robustness of the Solution and Quality of Guardrails | 30% | 30% |
| Architecture and Performance Efficiency | 20% | 20% |
| Security Reporting | 20% | 20% |
| Completeness of the Self-Testing Suite | **20%** | **15%** |
| Practical Implementability and Scalability | **10%** | **15%** |

**Факт джерел:** ваги Self-Testing і Practical різняться. Остаточне уточнення залишається у [відкритих питаннях](07-open-questions.md); цей документ не встановлює нові ваги.

## Як судді перевірятимуть (CRIETRIA, розд. 6) — читати перед кожним прогоном

| Механізм | Дослівно | Наслідок для нас |
|---|---|---|
| Судді запускають наш тест-сьют | «Judges will execute the automated test suite provided by the team» | Підготувати відтворюваний запуск `make test` за [README](../README.md); результати перенесення та пропуски — у [transfer](transfer.md) |
| Спонтанні дії | «spontaneous, zero- preparation actions» | Демо не має залежати від заздалегідь прогрітого стану |
| Живі ad-hoc промпти | «interactively test the running control layer in real time using spontaneous, ad-hoc prompts» | **Найбільший ризик.** Шар мусить реагувати на довільний текст, а не лише на структуровані виклики |
| Зміна конфігурації | «may modify the configuration files/feeds … changing rules, removing controls, adjusting thresholds … can they adjust in real-time» | Перезавантаження політики наживо — обов'язкове; зняття контролю не має ламати шар |
| Телеметрія | «You should be able to produce performance telemetry as it may be used for evaluation» | Латентність і метрики — на екран, не в лог |

**Пропозиція, висока впевненість:** стовпець «Наслідок для нас» є інтерпретацією для підготовки демонстрації, а не додатковою вимогою організаторів чи обіцянкою оцінки.

## Де перевіряти реалізацію та докази

| Поверхня | Контракт | Датовані докази та межі |
|---|---|---|
| Захищені виклики й конфігурація | [invocation](../app/contracts/invocation.md), [configuration](../app/contracts/configuration.md) | [Перевірки копії](transfer.md), [лог](../sources/export-unit-tests.log) |
| Панель і звітність | [panel](../app/contracts/control-panel.md), [reporting](../app/contracts/reporting.md) | [Інтеграція](../sources/original-panel-integration-2026-10-03.md), [виправлення](../sources/operator-fixes-2026-10-04.md) |
| MCP і відновлення операцій | [operations](../app/contracts/mcp-operations.md) | [MCP fixes](../sources/mcp-fixes-2026-10-04.md) |
| Модельний proxy | [Responses](../app/contracts/model-proxy.md) | [Звіт реалізації](../sources/model-proxy-implementation-2026-10-04.md) |

**Межа:** наявність коду або історичного прогону не доводить проходження всіх критеріїв. Якість семантичного захисту, продуктивність і повний набір сценаріїв не підтверджені цим оглядом. Новий runtime у сесії очищення не запускався. Підготовка сценаріїв — у [матриці](23-bash-scenario-matrix.md); рішення про подання належить власнику.
