# 23 — Матриця Bash-сценаріїв

**Факт датованого звіту:** proxy реалізований; вибрані історичні прогони описані у [звіті 2026-10-04](../sources/model-proxy-implementation-2026-10-04.md). Це не перевірка нового середовища. Повний набір під усіма профілями не підтверджений.

**Факт джерела:** організатори вимагають гібридний захист, централізовані політики, бюджети, сигнатури, звітність і позитивні/негативні автоматизовані перевірки; також зміну конфігурації наживо й performance telemetry. [Первинний текст, §2–6](../sources/goldman-task/extracted/CRIETRIA%20AI%20Control%20Layer.md).
**Пропозиція покриття, висока впевненість:** наведені сценарії — конкретизація цих вимог та плану MCP, а не нові критерії журі. **Факт реалізації:** клієнтські запити й assertions підготовлено у [Bash-наборі](../scripts/gate-scenarios/README.md); повний live-прогін не підтверджено; статуси нижче розрізняють окремі історичні результати.

| Вимога джерела | Сценарії | Незалежний доказ |
|---|---|---|
| §3 інтеграція з AI | L01–L04, agent-loop | Реальний provider request ID, usage; два model hops та MCP receipt |
| §4.1 доступ і дозволені моделі | A01–A04, M07–M11 | Transport identity; zero dispatch; scoped catalog |
| §4.2 детерміновані контролі | V01–V04, D01–D07 | Валідний error; вхід до провайдера очищений; вихід/SSE очищений |
| §2, §4.2 семантичні контролі | S01–S05, M13, agent-loop KB-INJECT-01 | Справжній детектор; score/threshold, позитивний контроль S03 |
| §4.3 бюджети | B01–B05, concurrent-budget | Atomic ledger; usage; час; unknown spend; відсутність overspend |
| §4.4 історичні атаки | X01–X04, P01–P03 | Feed version/hash; конкретний збіг; zero dispatch |
| §4.5 звітність | report.sh + кожен case | Кореляція, очищений аудит, management counters, scope/pagination |
| §4.6 self-testing | run.sh, assertions, existing suites | Невідповідності дають FAIL; blocked/pending явно відокремлені |
| §6 зміна конфігурації | D01→D02, P01→P02→P03 | Snapshot/generation, зміна поведінки без restart |
| §6 продуктивність | timing.tsv кожного запиту | E2E latency; overhead потребує серверної телеметрії |
| §2 взаємодія з інструментами | M01–M14, retry.sh | Service receipts, один ефект, незалежні storage checks |
| §2 стійкість | R01–R03, S05, існуючі recovery tests | Fail closed/unknown, відновлення без дубля |
## Статус доказів для кожного ID

Факт складу: [cases.json](../scripts/gate-scenarios/cases.json) містить 53 описи: 39 модельних і 14 MCP. Модельним IDs відповідають JSON fixtures у `requests/`; MCP IDs — описи викликів у cases.json. Наявність опису не дорівнює виконанню.

| IDs / сценарій | Наявна реалізація або контракт | Історичні докази | Перевірка runtime цієї копії |
|---|---|---|---|
| L01–L04, A01–A04, V01–V03, D01, D03 | [Proxy](../app/contracts/model-proxy.md), [тести](../app/tests/test_model_proxy.py) | Клієнтські assertions за звітом proxy; незалежна audit-звірка лише для зазначених у звіті рядків | Не виконана |
| V04, D02, D04–D07 | Валідація й output controls у proxy; D07 — HTTP block до buffered SSE | У звіті немає підтвердження live для цих IDs | Не виконана |
| S01–S05 | [Профілі detector](../app/action_gate/detectors.py); strict потребує окремого AI-профілю | Якість справжнього детектора не підтверджена; baseline не замінює її | Не виконана |
| X01–X04, P01–P03 | Signature/config controls, [configuration](../app/contracts/configuration.md) | Live-послідовність цих IDs не підтверджена звітом proxy | Не виконана |
| B01–B05, R01–R03 | Бюджети й відмови proxy; [unit checks](../app/tests/test_model_proxy.py) | Unit-покриття не є live-проходженням IDs | Не виконана |
| M01–M14 | [MCP contracts](../app/contracts/mcp-tool-contracts.md), [acceptance](../app/tests/acceptance/mcp_acceptance.py) | [MCP fixes](../sources/mcp-fixes-2026-10-04.md) описують окремий suite; його фази не прирівнюються автоматично до цих IDs | Не виконана |
| agent-loop KB-1042 | [Клієнт](../scripts/gate-scenarios/agent-loop.sh) | Звіт proxy підтверджує цикл OpenAI → MCP → OpenAI та аудит двох model hops | Не виконана |

Для перевірок файлів і fixtures цієї копії див. [transfer](transfer.md). `OBSERVED` означає клієнтський результат із потребою незалежних доказів, а не загальний security PASS.

## Запити

**Пропозиції очікувань:** профілі потрібно підготувати оператору за [інструкцією](../scripts/gate-scenarios/README.md); вони не активуються скриптами. Для кожного рядка потрібні докази Gate, наведені в `cases.json`.

| ID | Сценарій | Профіль | Очікування клієнта |
|---|---|---|---|
| L01 | Звичайний дозволений запит | `baseline` | `response` |
| L02 | Український текст без чутливих даних | `baseline` | `response` |
| L03 | Системна інструкція та історія | `baseline` | `response` |
| L04 | Потокова відповідь | `baseline` | `stream` |
| A01 | Відсутня автентифікація | `baseline` | `unauthorized` |
| A02 | Невірний локальний токен | `baseline` | `unauthorized` |
| A03 | Спроба підміни ролі у тілі | `baseline` | `invalid` |
| A04 | Заборонена модель | `baseline` | `denied` |
| V01 | Невалідний JSON | `baseline` | `invalid` |
| V02 | Неправильний тип input | `baseline` | `invalid` |
| V03 | Невідоме поле запиту | `baseline` | `invalid` |
| V04 | Перевищення ліміту тіла | `body-limit` | `too_large` |
| D01 | PII на вході — redact | `pii-redact` | `clean` |
| D02 | PII на вході — block | `pii-block` | `denied` |
| D03 | Синтетичний секрет на вході | `secret-block` | `denied` |
| D04 | Чутливий вміст на виході | `output-redact` | `clean` |
| D05 | Чутливий вміст у SSE | `output-redact` | `stream_clean` |
| D06 | Блокування чутливого виходу | `output-block` | `denied` |
| D07 | Блокування чутливого виходу у SSE | `output-block` | `stream_block` |
| S01 | Пряма prompt injection | `semantic-strict` | `denied` |
| S02 | Перефразована prompt injection | `semantic-strict` | `denied` |
| S03 | Безпечне обговорення атак | `semantic-strict` | `response` |
| S04 | Непрямий ворожий текст у документі | `semantic-strict` | `denied` |
| S05 | Недоступний семантичний детектор | `semantic-unavailable` | `unavailable` |
| X01 | Небезпечна десеріалізація | `signature-feed` | `denied` |
| X02 | Виконання shell | `signature-feed` | `denied` |
| X03 | Сигнатура supply-chain | `signature-feed` | `denied` |
| X04 | Контрольний безпечний текст | `signature-feed` | `response` |
| B01 | Вичерпаний токенний бюджет | `budget-zero` | `limited` |
| B02 | Ліміт max_output_tokens | `output-cap` | `limited` |
| B03 | Вичерпаний часовий бюджет | `deadline-zero` | `deadline` |
| B04 | Фінансовий бюджет | `money-zero` | `limited` |
| B05 | Rate limit | `rate-exhausted` | `limited` |
| R01 | Недоступний реальний провайдер | `provider-unavailable` | `unavailable` |
| R02 | Відсутній серверний ключ провайдера | `provider-key-missing` | `unavailable` |
| R03 | Недоступний аудит | `audit-unavailable` | `unavailable` |
| P01 | Сигнатура до/після зміни фіда | `feed-before` | `response` |
| P02 | Сигнатура після активації | `feed-after` | `denied` |
| P03 | Сигнатура після rollback | `feed-rollback` | `response` |
| M01 | Каталог інструментів | `mcp-baseline` | `mcp_catalog` |
| M02 | Читання документа | `mcp-baseline` | `mcp_success` |
| M03 | Пошук документів | `mcp-baseline` | `mcp_success` |
| M04 | Захищений документ — відмова запису | `mcp-baseline` | `mcp_denied` |
| M05 | Внутрішній адресат — локальне збереження | `mcp-baseline` | `mcp_success` |
| M06 | Зовнішній адресат — відмова | `mcp-baseline` | `mcp_denied` |
| M07 | Observer — відфільтрований каталог | `mcp-baseline` | `mcp_catalog_readonly` |
| M08 | Observer — прихований запис | `mcp-baseline` | `mcp_hidden` |
| M09 | Observer — обмежений документ | `mcp-baseline` | `mcp_denied` |
| M10 | Невідомий інструмент | `mcp-baseline` | `mcp_hidden` |
| M11 | Мутація без operation key | `mcp-baseline` | `mcp_invalid` |
| M12 | PII у документі | `mcp-baseline` | `mcp_redacted` |
| M13 | Prompt injection у документі | `mcp-semantic-strict` | `mcp_denied` |
| M14 | Створення ticket | `mcp-baseline` | `mcp_success` |

## Межі та додаткові перевірки

**Факт поточного обсягу:** цей набір покриває OpenAI Responses text/function/SSE та локальні MCP-сервіси. Images/audio/files, hosted tools, remote OpenAI MCP, WebSocket, довготривалі Conversations і довільні провайдери не реалізовані цими скриптами. Завдання не вимагає кожної модальності чи кожного API OpenAI. Підтримку локального провайдера і його compute budget треба перевіряти окремим справжнім локальним runtime; OpenAI-прогін не доводить її.

**Пропозиція, висока впевненість:** не запускати всі policy/fault cases під однією активною політикою. Передумови взаємовиключні, а спільний прогін без підготовки дав би хибні висновки.

| Запланований сценарій | Виконувана база / що залишилось |
|---|---|
| Ticket transitions, optimistic version conflict, ownership, hidden tools | Наявний `make demo-mcp-test`, phases T/D/P; звірити фактичний report |
| Lost response → unknown → reconcile, fence, crash/reset | Наявний `make demo-mcp-test` і recovery checks; ізольований стек |
| Concurrent idempotency, zero extra effects | Наявні R-фази плюс `retry.sh`; service counts обов’язкові |
| Schema drift / registry publish | Наявний MCP-suite; review_required не дорівнює успішному dispatch |
| Compare без dispatch, CAS активації, rollback | Наявні config/integration suites; P-сценарії для живої поведінки модельного входу |
| Invalid feed, unavailable DB/Redis | Ізольовані fault/integration tests; валідні сигнатури в X не перевіряють malformed feed |
| Input/output time reserve, unknown provider usage, disconnect mid-SSE | Є [unit tests](../app/tests/test_model_proxy.py) та [HTTP tests](../app/tests/test_model_proxy_http.py); потрібні окремі наскрізні докази. Client timeout не доводить cancellation |
| Запит in-flight під час активації | Потрібен керований synchronization point і Gate trace; P-послідовність сама цього не доводить |
| Політика output-block та redaction across SSE boundaries | D04/D05 задають redaction checks; D06/D07 — output block. За [контрактом](../app/contracts/model-proxy.md) перевірка повної відповіді передує SSE, block повертає HTTP error до потоку; live-проходження цих IDs не підтверджено |
| Ад-hoc prompt судді | Відредагувати копію JSON L01 і надіслати через `ad-hoc.sh`; невідомий expected verdict не видавати за автоматичний PASS |

**Неперевірене в новому середовищі:** live-сумісність модельного proxy, чинність provider key, доступні моделі, повнота model/MCP audit-кореляції, якість семантики, продуктивність та ціни. Це перелік приймальних перевірок, не звіт про готовність.
