# Міграції основної БД

Оновлено 2026-10-04 за [runner](../action_gate/migrate.py) і SQL цього каталогу. Окремий job `migrate` у [Compose](../../compose.yaml) запускає runner; API і MCP ingress чекають `service_completed_successfully`. Сам [Dockerfile](../Dockerfile) не застосовує міграції. Цей опис не є новим прогоном проти PostgreSQL.

## Склад схеми

| Міграція | Призначення |
|---|---|
| [0001_init.sql](0001_init.sql) | Початкова схема викликів, аудиту, бюджетів, ефектів і синтетичних документів |
| [0002_idempotency_claim.sql](0002_idempotency_claim.sql) | Claim ключа ідемпотентності, overdraft і budget scope |
| [0003_policy_lifecycle.sql](0003_policy_lifecycle.sql) | Snapshot релізу, чернетки й активації, principal-scoped claims і provenance |
| [0004_control_panel.sql](0004_control_panel.sql) | Окремий JSON-стан оригінальної панелі в `control_panel_state` |
| [0005_mcp_registry.sql](0005_mcp_registry.sql) | Версії MCP registry, один активний revision та стан сервісів |
| [0006_remote_operations.sql](0006_remote_operations.sql) | Durable MCP operations, attempts, audit, concurrency reservations і demo run state |

## Поведінка runner

**Факт коду:** `python -m action_gate.migrate` читає `*.sql` у порядку назв, використовує `schema_migrations` для обліку застосованих файлів і пропускає вже застосовані версії. Каталог можна задати через `APP_MIGRATIONS_DIR`. Session-level `pg_advisory_lock` утримується на час прогону до закриття з’єднання, щоб два runner не застосували один файл одночасно.

**Межі:** автоматичного downgrade або перевірки checksum уже застосованого SQL цей runner не виконує. Нові зміни оформлювати наступним номером; редагування застосованого SQL не змусить runner виконати його повторно. Не видаляти volumes або живі дані для застосування міграції.

## Політики та стан

**Факт контракту:** після bootstrap активний legacy-реліз і його документи зберігаються у PostgreSQL; `app/policy/` — формат bootstrap/import, а не живе джерело політики. Див. [configuration](../contracts/configuration.md). Панель має окремий стан і lifecycle, див. [control-panel](../contracts/control-panel.md). Модельний proxy фіксує обидва snapshots, але не робить їх одним атомарним релізом — [model-proxy](../contracts/model-proxy.md).

Аудит, ledger та claims не можна відновлювати очищенням Redis; гарантії й межі конкретного шляху описані в [invocation](../contracts/invocation.md) та [MCP operations](../contracts/mcp-operations.md). Історичні перевірки копії — у [transfer](../../docs/transfer.md).
