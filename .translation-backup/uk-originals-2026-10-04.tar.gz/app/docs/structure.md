# Структура Action Gate

Карта поточної копії від 2026-10-04. Версія застосунку — `0.2.0` за [VERSION](../../VERSION) та [модулем версії](../action_gate/__init__.py). Нижче описано наявні файли й межі з контрактів; це не звіт нового runtime-прогону.

## Каталоги

| Каталог | Призначення |
|---|---|
| [action_gate/](../action_gate/) | HTTP, політики, enforcement, MCP, proxy, звітність і сховища |
| [dummy_mcp/](../dummy_mcp/) | Синтетичні Documents, Outbox, Tickets та спільний транспорт/стан |
| [demo_client/](../demo_client/) | Сценарний MCP-клієнт |
| [static/](../static/) | Legacy workbench і панель `/control/` |
| [policy/](../policy/) | Bootstrap/import конфігурація; окремий seed панелі — [panel_seed.json](../panel_seed.json) |
| [contracts/](../contracts/README.md) | Межі API й поведінки кожного шляху |
| [migrations/](../migrations/README.md) | Шість міграцій PostgreSQL |
| [tests/](../tests/) | Unit, HTTP, integration та acceptance перевірки |
| [scripts/](../../scripts/) | Запуск, перевірки UI, MCP і [сценарний клієнт](../../scripts/gate-scenarios/README.md) |
| [infra/](../../infra/) | Маршрути Traefik і пояснення init PostgreSQL; запуск — [Compose](../../compose.yaml) |

## Шляхи виконання та політики

| Поверхня | Основні модулі | Межа |
|---|---|---|
| `/v1/invocations`, `/v1/config/*` | [gateway.py](../action_gate/gateway.py), [config_service.py](../action_gate/config_service.py), [snapshot.py](../action_gate/snapshot.py), [evaluation.py](../action_gate/evaluation.py) | Активний legacy snapshot з PostgreSQL; draft/compare/activate/rollback; синтетичний Document Desk |
| `/v1/panel/*` | [panel_service.py](../action_gate/panel_service.py), [panel_engine.py](../action_gate/panel_engine.py) | Окрема політика й стан панелі; synthetic invoke, compare, review і replay |
| `/mcp` | [mcp_server.py](../action_gate/mcp_server.py), [execution.py](../action_gate/execution.py), [mcp_upstream.py](../action_gate/mcp_upstream.py) | Панельні контролі, перевірений registry, контрольований dispatch до dummy-сервісів |
| MCP lifecycle | [service_registry.py](../action_gate/service_registry.py), [mcp_ops.py](../action_gate/mcp_ops.py), [mcp_bootstrap.py](../action_gate/mcp_bootstrap.py) | Публікація каталогу, reconcile/fence/reset; невідомий outcome не означає відсутність ефекту |
| `/v1/responses` | [model_proxy.py](../action_gate/model_proxy.py), [model_proxy_setup.py](../action_gate/model_proxy_setup.py) | Фіксує panel policy і legacy release окремо; реальний provider за наявності конфігурації; буферизований SSE |
| Звітність | [operator_reporting.py](../action_gate/operator_reporting.py), [http_server.py](../action_gate/http_server.py) | Узгоджені представлення подій не об’єднують policy lifecycle в один реліз |

Сумісність transport і tool schemas — в [MCP profile](../contracts/mcp-protocol-profile.md) та [tool contracts](../contracts/mcp-tool-contracts.md). Спільні identity і сховище не роблять compare-докази різних поверхонь взаємозамінними.

## Спільні модулі

- [identity.py](../action_gate/identity.py) — ідентичність із транспорту; локальні principals не є production IAM.
- [content.py](../action_gate/content.py), [detectors.py](../action_gate/detectors.py), [config_bundle.py](../action_gate/config_bundle.py) — контентні перевірки, профілі детектора й конфігураційні документи. Offline baseline не є навченою моделлю.
- [budget.py](../action_gate/budget.py), [audit.py](../action_gate/audit.py), [services.py](../action_gate/services.py) — резерви, очищений аудит і синтетична дія legacy-шляху.
- [storage/](../action_gate/storage/) — PostgreSQL, memory, config store, operations і Redis runtime. Memory backend не доводить durability.
- [migrate.py](../action_gate/migrate.py) — лінійні SQL-міграції з session advisory lock і журналом застосування; автоматичного downgrade немає.

## Як продовжувати

**Пропозиція, висока впевненість:** зміни прив’язувати до конкретної поверхні, її контракту й тестів. Не приписувати гарантії MCP модельному proxy або legacy-виклику без окремої перевірки. Якість семантики, performance та новий запуск копії залишаються окремими роботами; актуальні межі — [transfer](../../docs/transfer.md), [питання](../../docs/07-open-questions.md), [матриця сценаріїв](../../docs/23-bash-scenario-matrix.md).
