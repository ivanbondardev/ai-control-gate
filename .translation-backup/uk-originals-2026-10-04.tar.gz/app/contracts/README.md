# Контракти HTTP

**Факт реалізації:** нижче описані контракти шлюзу `0.2.0` та окрема серверна поверхня відновленого оригінального frontend. Контракт панелі фіксує реалізовану поведінку, а не результат ще не завершеного прогону перевірок.

| Документ | Що фіксує | Реалізація |
|---|---|---|
| [invocation.md](invocation.md) | один захищений виклик: запит, відповідь, три окремі відповіді (input decision, action outcome, output disclosure), мапінг статусів, ідемпотентність із скоупом на principal, межі аудиту | [gateway.py](../action_gate/gateway.py), [contracts.py](../action_gate/contracts.py) |
| [configuration.md](configuration.md) | життєвий цикл політик: snapshot, draft, compare, activate, rollback, export/import, bootstrap | [config_service.py](../action_gate/config_service.py), [snapshot.py](../action_gate/snapshot.py), [evaluation.py](../action_gate/evaluation.py) |
| [reporting.md](reporting.md) | звітність: одне вікно для всіх метрик, пагінація, латентність, ownership, експорт аудиту | [http_server.py](../action_gate/http_server.py), [storage/](../action_gate/storage) |
| [control-panel.md](control-panel.md) | оригінальний visual/YAML builder: чернетки, правила доступу, compare/activate, локальні synthetic-виклики, каталог, sanitized replay, reviews та JSONL export; окрема політика від legacy gateway | [panel_service.py](../action_gate/panel_service.py), [panel_engine.py](../action_gate/panel_engine.py), [panel.js](../static/control/panel.js) |
| [mcp-protocol-profile.md](mcp-protocol-profile.md) | MCP-профіль сумісності: ревізія протоколу, транспорт Streamable HTTP у JSON-режимі без сесій, автентифікація до транспорту, `_meta` як контрольний канал, перевірені обмеження SDK 2.x | [mcp_server.py](../action_gate/mcp_server.py), [dummy_mcp/common/service.py](../dummy_mcp/common/service.py) |
| [mcp-tool-contracts.md](mcp-tool-contracts.md) | контракти інструментів трьох dummy-сервісів: схеми, квитанції, словник помилок, ліміти, два хопи з різними словниками | [dummy_mcp/](../dummy_mcp/), [service_registry.py](../action_gate/service_registry.py) |
| [mcp-operations.md](mcp-operations.md) | одна операція: durable claim, ідемпотентність і конфлікти, unknown/reconcile/fence, reset, ліміти, формат аудиту й два незалежні канали доказів | [execution.py](../action_gate/execution.py), [storage/operations.py](../action_gate/storage/operations.py), [mcp_ops.py](../action_gate/mcp_ops.py) |

**Межа панелі:** активація через `/v1/panel/*` змінює поведінку `/v1/panel/invoke`, але не `/v1/invocations` і не `/v1/config/*`. Спільні сервер, реєстр ідентичностей та сховище не роблять політики й докази порівняння взаємозамінними. [Контракт і джерела реалізації](control-panel.md).

**Що змінилося від `0.1.0`:** `releaseHash` тепер описує саме виконані правила, а не байти файлів; виклик тримає один незмінний snapshot; `PUT /v1/config/drafts/{id}` та решта lifecycle-маршрутів додані; ключ ідемпотентності скоупиться на principal; `GET /v1/invocations` і `GET /v1/audit/events` додані; вікно звітності валідується, а не приймається мовчки. Історичні описи — у передачі 0.1.0 (archive reference: `../../docs/18-release-0.1.0-handoff.md`).

**Межа, висока впевненості:** контракти версійовано як `0.2.0` разом із релізом. Це не заморожений публічний API: автентифікація локальна й синтетична, TLS, OIDC і рольова модель продукційного рівня не входять в обсяг. Зміна, що ламає сумісність, потребує нової версії контракту, а не тихої правки.

**Пропозиція, висока впевненість:** додавати нові маршрути лише разом із записаним наміром, хто їх викликає (агент, оператор чи службова перевірка), який доказ вони дають і який тест це підтверджує. Маршрут без такого зв'язку не має розширювати поверхню атаки гейта. Повний перелік відкритих питань — у [журналі рішень](../../docs/07-open-questions.md).

- [OpenAI Responses model proxy](model-proxy.md): implemented profile, policy, budgets, buffered SSE and operator setup.
